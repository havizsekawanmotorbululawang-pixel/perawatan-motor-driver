import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('id_ID', null);
  await AppStore.instance.load();
  runApp(const DriverCareApp());
}

final money = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp', decimalDigits: 0);
final dateFmt = DateFormat('dd MMM yyyy', 'id_ID');

class AppStore extends ChangeNotifier {
  AppStore._();
  static final instance = AppStore._();
  late SharedPreferences prefs;

  double balance = 0;
  double savings = 0;
  double dailyTargetPercent = 10;
  double totalIncome = 0;
  double totalExpense = 0;
  double? startKm;
  bool working = false;
  String? startTime;
  String? startPhoto;
  double lastOilKm = 0;
  double oilIntervalKm = 2000;
  double currentOdometer = 0;
  final List<Map<String, dynamic>> attendance = [];
  final List<Map<String, dynamic>> transactions = [];
  final List<Map<String, dynamic>> services = [];
  final List<Map<String, dynamic>> maintenance = [];

  Future<void> load() async {
    prefs = await SharedPreferences.getInstance();
    balance = prefs.getDouble('balance') ?? 0;
    savings = prefs.getDouble('savings') ?? 0;
    dailyTargetPercent = prefs.getDouble('dailyTargetPercent') ?? 10;
    totalIncome = prefs.getDouble('totalIncome') ?? 0;
    totalExpense = prefs.getDouble('totalExpense') ?? 0;
    working = prefs.getBool('working') ?? false;
    startKm = prefs.getDouble('startKm');
    startTime = prefs.getString('startTime');
    startPhoto = prefs.getString('startPhoto');
    lastOilKm = prefs.getDouble('lastOilKm') ?? 0;
    oilIntervalKm = prefs.getDouble('oilIntervalKm') ?? 2000;
    currentOdometer = prefs.getDouble('currentOdometer') ?? 0;
    _loadList('attendance', attendance);
    _loadList('transactions', transactions);
    _loadList('services', services);
    _loadList('maintenance', maintenance);
    notifyListeners();
  }

  void _loadList(String key, List<Map<String, dynamic>> target) {
    final raw = prefs.getString(key);
    if (raw != null) {
      target
        ..clear()
        ..addAll((jsonDecode(raw) as List).cast<Map<String, dynamic>>());
    }
  }

  Future<void> _save() async {
    await prefs.setDouble('balance', balance);
    await prefs.setDouble('savings', savings);
    await prefs.setDouble('dailyTargetPercent', dailyTargetPercent);
    await prefs.setDouble('totalIncome', totalIncome);
    await prefs.setDouble('totalExpense', totalExpense);
    await prefs.setBool('working', working);
    if (startKm != null) {
      await prefs.setDouble('startKm', startKm!);
    } else {
      await prefs.remove('startKm');
    }
    if (startTime != null) {
      await prefs.setString('startTime', startTime!);
    } else {
      await prefs.remove('startTime');
    }
    if (startPhoto != null) { await prefs.setString('startPhoto', startPhoto!); } else { await prefs.remove('startPhoto'); }
    await prefs.setDouble('lastOilKm', lastOilKm);
    await prefs.setDouble('oilIntervalKm', oilIntervalKm);
    await prefs.setDouble('currentOdometer', currentOdometer);
    await prefs.setString('attendance', jsonEncode(attendance));
    await prefs.setString('transactions', jsonEncode(transactions));
    await prefs.setString('services', jsonEncode(services));
    await prefs.setString('maintenance', jsonEncode(maintenance));
    notifyListeners();
  }

  Future<void> startShift(double km, String photoPath) async {
    startKm = km;
    startPhoto = photoPath;
    currentOdometer = km;
    startTime = DateTime.now().toIso8601String();
    working = true;
    await _save();
  }

  Future<void> finishShift(double endKm, double income, double fuel, String endPhoto) async {
    if (!working || startKm == null) return;
    final distance = endKm - startKm!;
    if (distance < 0) throw Exception('Kilometer akhir tidak boleh lebih kecil.');
    final reserve = income * dailyTargetPercent / 100;
    balance += income - reserve - fuel;
    savings += reserve;
    totalIncome += income;
    totalExpense += fuel;
    attendance.insert(0, {
      'date': DateTime.now().toIso8601String(),
      'startKm': startKm,
      'endKm': endKm,
      'distance': distance,
      'income': income,
      'fuel': fuel,
      'reserve': reserve,
      'startPhoto': startPhoto,
      'endPhoto': endPhoto,
    });
    transactions.insert(0, {
      'date': DateTime.now().toIso8601String(),
      'title': 'Penghasilan narik',
      'amount': income,
      'type': 'income',
    });
    if (reserve > 0) {
      transactions.insert(0, {
        'date': DateTime.now().toIso8601String(),
        'title': 'Penyisihan tabungan perawatan',
        'amount': reserve,
        'type': 'saving',
      });
    }
    if (fuel > 0) {
      transactions.insert(0, {
        'date': DateTime.now().toIso8601String(),
        'title': 'Pengeluaran bensin',
        'amount': fuel,
        'type': 'expense',
      });
    }
    currentOdometer = endKm;
    working = false;
    startKm = null;
    startTime = null;
    startPhoto = null;
    await _save();
  }

  Future<void> addManualSaving(double amount) async {
    if (amount <= 0 || amount > balance) throw Exception('Nominal tidak valid atau saldo kurang.');
    balance -= amount;
    savings += amount;
    transactions.insert(0, {
      'date': DateTime.now().toIso8601String(),
      'title': 'Penyisihan manual',
      'amount': amount,
      'type': 'saving',
    });
    await _save();
  }

  Future<void> addIncome(double amount, String note) async {
    if (amount <= 0) return;
    balance += amount;
    totalIncome += amount;
    transactions.insert(0, {
      'date': DateTime.now().toIso8601String(),
      'title': note,
      'amount': amount,
      'type': 'income',
    });
    await _save();
  }

  Future<void> payService(String title, double amount) async {
    if (amount <= 0 || amount > balance) throw Exception('Saldo tidak mencukupi.');
    balance -= amount;
    totalExpense += amount;
    services.insert(0, {
      'date': DateTime.now().toIso8601String(),
      'title': title,
      'amount': amount,
    });
    transactions.insert(0, {
      'date': DateTime.now().toIso8601String(),
      'title': 'Pembayaran: $title',
      'amount': amount,
      'type': 'expense',
    });
    await _save();
  }

  Future<void> addMaintenance(String title, String km, String note) async {
    maintenance.insert(0, {
      'date': DateTime.now().toIso8601String(),
      'title': title,
      'km': km,
      'note': note,
    });
    await _save();
  }

  Future<void> setOilSchedule(double lastKm, double intervalKm, double currentKm) async {
    lastOilKm = lastKm; oilIntervalKm = intervalKm; currentOdometer = currentKm; await _save();
  }

  Future<void> setSavingPercent(double value) async {
    dailyTargetPercent = value.clamp(0, 100);
    await _save();
  }
}

class DriverCareApp extends StatelessWidget {
  const DriverCareApp({super.key});
  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: AppStore.instance,
      builder: (context, _) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Perawatan Motor Driver',
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF16BFA5)),
          scaffoldBackgroundColor: const Color(0xFFF2F6FA),
          appBarTheme: const AppBarTheme(
            backgroundColor: Color(0xFF0B1426),
            foregroundColor: Colors.white,
            centerTitle: false,
          ),
        ),
        home: const MainShell(),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [
    DashboardPage(), AttendancePage(), MaintenancePage(),
    CatalogPage(), FinancePage(), ProfilePage()
  ];
  final labels = const ['Beranda', 'Absensi', 'Perawatan', 'Katalog', 'Keuangan', 'Profil'];
  final icons = const [Icons.home_rounded, Icons.fact_check_rounded, Icons.build_rounded,
    Icons.storefront_rounded, Icons.account_balance_wallet_rounded, Icons.person_rounded];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: List.generate(labels.length, (i) =>
          NavigationDestination(icon: Icon(icons[i]), label: labels[i])),
      ),
    );
  }
}

Widget pageTitle(String title, String subtitle) => Padding(
  padding: const EdgeInsets.fromLTRB(18, 20, 18, 12),
  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
    const SizedBox(height: 4),
    Text(subtitle, style: TextStyle(color: Colors.grey.shade600)),
  ]),
);

Widget moneyCard(String title, String value, IconData icon, {Color color = const Color(0xFF176B4D)}) =>
  Card(elevation: 0, child: Padding(
    padding: const EdgeInsets.all(15),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      CircleAvatar(backgroundColor: color.withOpacity(.10), child: Icon(icon, color: color)),
      const SizedBox(height: 12),
      Text(title, style: TextStyle(color: Colors.grey.shade600, fontSize: 12)),
      const SizedBox(height: 5),
      FittedBox(fit: BoxFit.scaleDown, child: Text(value,
        style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 19))),
    ]),
  ));

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = AppStore.instance;
    return ListView(padding: const EdgeInsets.only(bottom: 18), children: [
      Container(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 25),
        decoration: const BoxDecoration(
          color: Color(0xFF124B38),
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(26)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('PERAWATAN MOTOR DRIVER', style: TextStyle(color: Colors.white70, letterSpacing: 1)),
          const SizedBox(height: 10),
          const Text('Halo, Driver! 👋', style: TextStyle(color: Colors.white, fontSize: 25, fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          Text(DateFormat('EEEE, dd MMMM yyyy', 'id_ID').format(DateTime.now()),
            style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 18),
          Row(children: [
            Icon(s.working ? Icons.circle : Icons.circle_outlined,
              color: s.working ? Colors.lightGreenAccent : Colors.white70, size: 12),
            const SizedBox(width: 8),
            Text(s.working ? 'Sedang narik' : 'Belum mulai narik',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
          ]),
        ]),
      ),
      Padding(padding: const EdgeInsets.all(14), child: Column(children: [
        Row(children: [
          Expanded(child: moneyCard('Saldo tersedia', money.format(s.balance), Icons.account_balance_wallet)),
          Expanded(child: moneyCard('Tabungan servis', money.format(s.savings), Icons.savings)),
        ]),
        Row(children: [
          Expanded(child: moneyCard('Total pemasukan', money.format(s.totalIncome), Icons.trending_up)),
          Expanded(child: moneyCard('Total pengeluaran', money.format(s.totalExpense), Icons.receipt_long, color: Colors.deepOrange)),
        ]),
        const SizedBox(height: 8),
        Card(elevation: 0, child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.two_wheeler)),
          title: const Text('Perawatan motor'),
          subtitle: Text('${s.maintenance.length} catatan perawatan tersimpan'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const MaintenancePage())),
        )),
        Card(elevation: 0, child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.fact_check)),
          title: const Text('Absensi & kilometer'),
          subtitle: Text('${s.attendance.length} hari tercatat'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AttendancePage())),
        )),
        Card(elevation: 0, child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.qr_code_2)),
          title: const Text('Pembayaran QRIS'),
          subtitle: const Text('Lihat QRIS merchant'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const QrisPage())),
        )),
      ])),
    ]);
  }
}

class AttendancePage extends StatefulWidget {
  const AttendancePage({super.key});
  @override
  State<AttendancePage> createState() => _AttendancePageState();
}
class _AttendancePageState extends State<AttendancePage> {
  final start = TextEditingController();
  final end = TextEditingController();
  final income = TextEditingController();
  final fuel = TextEditingController();
  final picker = ImagePicker();

  Future<String?> capturePhoto() async {
    final image = await picker.pickImage(source: ImageSource.camera, imageQuality: 75, maxWidth: 1280);
    if (image == null) return null;
    final directory = await getApplicationDocumentsDirectory();
    final saved = '${directory.path}/attendance_${DateTime.now().microsecondsSinceEpoch}.jpg';
    return (await File(image.path).copy(saved)).path;
  }

  Future<void> begin() async {
    final km = double.tryParse(start.text.replaceAll(',', '.'));
    if (km == null || km < 0) return _msg('Masukkan kilometer awal yang benar.');
    final photo = await capturePhoto();
    if (photo == null) return _msg('Foto wajib diambil untuk memulai absensi.');
    await AppStore.instance.startShift(km, photo);
    start.clear();
    setState(() {});
    _msg('Absensi mulai narik berhasil dicatat.');
  }
  Future<void> finish() async {
    final s = AppStore.instance;
    final km = double.tryParse(end.text.replaceAll(',', '.'));
    final inc = double.tryParse(income.text.replaceAll(',', '.')) ?? 0;
    final fuelCost = double.tryParse(fuel.text.replaceAll(',', '.')) ?? 0;
    if (km == null) return _msg('Masukkan kilometer akhir.');
    final photo = await capturePhoto();
    if (photo == null) return _msg('Foto wajib diambil untuk menyelesaikan absensi.');
    try {
      await s.finishShift(km, inc, fuelCost, photo);
      end.clear(); income.clear(); fuel.clear();
      setState(() {});
      _msg('Absensi selesai. Tabungan harian sudah dihitung.');
    } catch (e) { _msg(e.toString().replaceAll('Exception: ', '')); }
  }
  void _msg(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  @override
  Widget build(BuildContext context) {
    final s = AppStore.instance;
    return ListView(padding: const EdgeInsets.only(bottom: 20), children: [
      pageTitle('Absensi Harian', 'Catat waktu kerja dan kilometer setelah narik.'),
      Card(elevation: 0, margin: const EdgeInsets.symmetric(horizontal: 16), child: Padding(
        padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const Icon(Icons.timer, color: Color(0xFF176B4D)), const SizedBox(width: 8),
            Text(s.working ? 'Status: Sedang narik' : 'Status: Belum mulai', style: const TextStyle(fontWeight: FontWeight.bold))]),
          const SizedBox(height: 14),
          if (!s.working) ...[
            field(start, 'Kilometer awal', 'Contoh: 12500', number: true),
            const SizedBox(height: 12),
            const Text('Foto selfie wajib diambil langsung dari kamera.', style: TextStyle(fontSize: 12, color: Colors.deepOrange)),
            FilledButton.icon(onPressed: begin, icon: const Icon(Icons.camera_alt), label: const Text('Foto & Mulai Narik')),
          ] else ...[
            Text('Mulai: ${s.startTime == null ? '-' : DateFormat('HH:mm').format(DateTime.parse(s.startTime!))}'),
            const SizedBox(height: 12),
            field(end, 'Kilometer akhir', 'Contoh: 12585', number: true),
            field(income, 'Penghasilan hari ini (Rp)', 'Contoh: 200000', number: true),
            field(fuel, 'Pengeluaran bensin (Rp)', 'Contoh: 25000', number: true),
            const SizedBox(height: 12),
            const Text('Ambil foto selfie lagi untuk bukti selesai narik.', style: TextStyle(fontSize: 12, color: Colors.deepOrange)),
            FilledButton.icon(onPressed: finish, icon: const Icon(Icons.camera_alt), label: const Text('Foto & Selesai Narik')),
          ],
          const SizedBox(height: 8),
          Text('Penyisihan otomatis saat selesai: ${s.dailyTargetPercent.toStringAsFixed(0)}% dari penghasilan.',
            style: TextStyle(color: Colors.grey.shade700, fontSize: 12)),
        ]),
      )),
      Padding(padding: const EdgeInsets.fromLTRB(18, 20, 18, 8),
        child: Text('Riwayat absensi', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))),
      if (s.attendance.isEmpty) const EmptyState(text: 'Belum ada riwayat absensi.'),
      ...s.attendance.map((a) => Card(elevation: 0, margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: ListTile(
          leading: const CircleAvatar(child: Icon(Icons.route)),
          title: Text('${(a['distance'] as num).toStringAsFixed(1)} KM'),
          subtitle: Text('${dateFmt.format(DateTime.parse(a['date']))} • ${money.format(a['income'])}'),
          trailing: Text('${a['startKm']} → ${a['endKm']}', style: const TextStyle(fontSize: 11)),
          onTap: () => showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Bukti absensi'), content: Column(mainAxisSize: MainAxisSize.min, children: [if (a['startPhoto'] != null && File(a['startPhoto']).existsSync()) Image.file(File(a['startPhoto']), height: 150), if (a['endPhoto'] != null && File(a['endPhoto']).existsSync()) Image.file(File(a['endPhoto']), height: 150)]))),
        ))),
    ]);
  }
}

class MaintenancePage extends StatefulWidget {
  const MaintenancePage({super.key});
  @override
  State<MaintenancePage> createState() => _MaintenancePageState();
}
class _MaintenancePageState extends State<MaintenancePage> {
  final title = TextEditingController();
  final km = TextEditingController();
  final note = TextEditingController();
  final lastOil = TextEditingController();
  final intervalOil = TextEditingController(text: '2000');
  final currentKm = TextEditingController();
  final tasks = const ['Ganti oli mesin', 'Ganti oli gardan', 'Servis CVT', 'Periksa kampas rem',
    'Periksa ban', 'Periksa aki', 'Ganti busi', 'Bersihkan filter udara', 'Periksa lampu'];
  Future<void> add() async {
    if (title.text.trim().isEmpty) return;
    await AppStore.instance.addMaintenance(title.text.trim(), km.text.trim(), note.text.trim());
    title.clear(); km.clear(); note.clear();
    if (mounted) setState(() {});
  }
  @override
  Widget build(BuildContext context) {
    final s = AppStore.instance;
    return ListView(padding: const EdgeInsets.only(bottom: 20), children: [
      pageTitle('Perawatan Motor', 'Catat servis dan pantau kondisi kendaraan.'),
      Builder(builder: (context) {
        if (lastOil.text.isEmpty) lastOil.text = s.lastOilKm.toStringAsFixed(0);
        if (intervalOil.text.isEmpty) intervalOil.text = s.oilIntervalKm.toStringAsFixed(0);
        if (currentKm.text.isEmpty) currentKm.text = s.currentOdometer.toStringAsFixed(0);
        final due = s.lastOilKm + s.oilIntervalKm;
        final late = s.lastOilKm > 0 && s.currentOdometer >= due;
        final remaining = due - s.currentOdometer;
        return Card(elevation: 0, margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6), color: late ? const Color(0xFFFFE8E8) : const Color(0xFFE4F7EC), child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Icon(late ? Icons.warning_amber_rounded : Icons.check_circle, color: late ? Colors.red : Colors.green), const SizedBox(width: 8), Text('STATUS OLI', style: TextStyle(fontWeight: FontWeight.bold, color: late ? Colors.red.shade900 : Colors.green.shade900))]),
          const SizedBox(height: 6), Text(s.lastOilKm <= 0 ? 'Atur kilometer ganti oli terakhir' : late ? 'OLI TERLAMBAT — SEGERA GANTI' : 'OLI MASIH BAGUS', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: late ? Colors.red.shade800 : Colors.green.shade800)),
          Text(s.lastOilKm <= 0 ? 'Belum ada data jadwal oli.' : late ? 'Melewati jadwal ${remaining.abs().toStringAsFixed(0)} km' : 'Sisa ${remaining.toStringAsFixed(0)} km • Jadwal ${due.toStringAsFixed(0)} km', style: TextStyle(color: late ? Colors.red.shade800 : Colors.green.shade800)),
          const SizedBox(height: 12), field(lastOil, 'KM terakhir ganti oli', 'Contoh: 10000', number: true),
          field(intervalOil, 'Interval ganti oli (KM)', 'Contoh: 2000', number: true),
          field(currentKm, 'KM motor sekarang', 'Contoh: 11500', number: true),
          SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: () async { final a = double.tryParse(lastOil.text) ?? 0; final b = double.tryParse(intervalOil.text) ?? 2000; final c = double.tryParse(currentKm.text) ?? 0; if (a < 0 || b <= 0 || c < 0) return; await s.setOilSchedule(a, b, c); if (mounted) setState(() {}); }, icon: const Icon(Icons.save), label: const Text('Simpan jadwal oli'))),
          if (late) SizedBox(width: double.infinity, child: FilledButton(onPressed: () async { final c = double.tryParse(currentKm.text) ?? s.currentOdometer; await s.setOilSchedule(c, s.oilIntervalKm, c); await s.addMaintenance('Ganti oli mesin', c.toStringAsFixed(0), 'Jadwal oli diperbarui setelah penggantian.'); if (mounted) { lastOil.text = c.toStringAsFixed(0); setState(() {}); } }, child: const Text('Saya sudah ganti oli')))
        ])));
      }),
      Card(elevation: 0, margin: const EdgeInsets.symmetric(horizontal: 16), child: Padding(
        padding: const EdgeInsets.all(16), child: Column(children: [
          DropdownButtonFormField<String>(
            decoration: const InputDecoration(labelText: 'Jenis perawatan', border: OutlineInputBorder()),
            items: tasks.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) => title.text = v ?? '',
          ),
          const SizedBox(height: 10),
          field(km, 'Kilometer saat servis', 'Contoh: 12500', number: true),
          field(note, 'Catatan tambahan', 'Contoh: oli 10W-30'),
          FilledButton.icon(onPressed: add, icon: const Icon(Icons.save), label: const Text('Simpan Perawatan')),
        ]),
      )),
      Padding(padding: const EdgeInsets.all(18), child: Text('Riwayat perawatan',
        style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))),
      if (s.maintenance.isEmpty) const EmptyState(text: 'Belum ada catatan perawatan.'),
      ...s.maintenance.map((m) => Card(elevation: 0, margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: ListTile(leading: const CircleAvatar(child: Icon(Icons.build)),
          title: Text(m['title']), subtitle: Text('${dateFmt.format(DateTime.parse(m['date']))} • KM ${m['km']}\n${m['note']}')))),
    ]);
  }
}

class CatalogPage extends StatelessWidget {
  const CatalogPage({super.key});
  static const products = [
    ['Oli mesin 10W-30', 'Pelumas mesin motor matic', 65000, Icons.oil_barrel],
    ['Oli gardan', 'Pelumas final gear', 18000, Icons.water_drop],
    ['Kampas rem', 'Kampas rem depan / belakang', 45000, Icons.settings],
    ['Busi standar', 'Busi pengapian motor', 22000, Icons.electrical_services],
    ['Filter udara', 'Filter udara pengganti', 35000, Icons.air],
    ['Ban tubeless', 'Ban motor harian', 185000, Icons.tire_repair],
  ];
  static const jobs = [
    ['Jasa ganti oli', 15000], ['Jasa ganti oli gardan', 10000],
    ['Servis CVT', 75000], ['Jasa ganti kampas rem', 25000],
    ['Tambal ban', 15000], ['Tune up ringan', 60000],
  ];
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.only(bottom: 20), children: [
    pageTitle('Katalog Produk & Jasa', 'Harga contoh; admin dapat memperbarui harga pada pengembangan backend.'),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text('Produk sparepart',
      style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))),
    ...products.map((p) => Card(elevation: 0, margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      child: ListTile(leading: CircleAvatar(child: Icon(p[3] as IconData)),
        title: Text(p[0] as String), subtitle: Text(p[1] as String),
        trailing: Text(money.format(p[2]), style: const TextStyle(fontWeight: FontWeight.bold))))),
    Padding(padding: const EdgeInsets.fromLTRB(16, 20, 16, 8), child: Text('Ongkos jasa servis',
      style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))),
    ...jobs.map((j) => Card(elevation: 0, margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: ListTile(leading: const CircleAvatar(child: Icon(Icons.handyman)),
        title: Text(j[0] as String), trailing: Text(money.format(j[1]), style: const TextStyle(fontWeight: FontWeight.bold))))),
    const Padding(padding: EdgeInsets.all(16), child: Text(
      'Catatan: harga di katalog adalah contoh awal, bukan penawaran harga resmi bengkel. Konfirmasi harga dan ketersediaan sebelum transaksi.',
      style: TextStyle(fontSize: 12, color: Colors.grey))),
  ]);
}

class FinancePage extends StatefulWidget {
  const FinancePage({super.key});
  @override
  State<FinancePage> createState() => _FinancePageState();
}
class _FinancePageState extends State<FinancePage> {
  final amount = TextEditingController();
  final note = TextEditingController();
  Future<void> saveIncome() async {
    final v = double.tryParse(amount.text);
    if (v == null || v <= 0) return;
    await AppStore.instance.addIncome(v, note.text.trim().isEmpty ? 'Pemasukan tambahan' : note.text.trim());
    amount.clear(); note.clear();
    if (mounted) setState(() {});
  }
  Future<void> saveMoney() async {
    final v = double.tryParse(amount.text);
    if (v == null) return;
    try {
      await AppStore.instance.addManualSaving(v);
      amount.clear();
      if (mounted) setState(() {});
      _message('Penyisihan berhasil dicatat.');
    } catch (e) { _message(e.toString().replaceAll('Exception: ', '')); }
  }
  void _message(String m) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  @override
  Widget build(BuildContext context) {
    final s = AppStore.instance;
    return ListView(padding: const EdgeInsets.only(bottom: 20), children: [
      pageTitle('Keuangan Driver', 'Pantau saldo dan dana perawatan motor.'),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Row(children: [
        Expanded(child: moneyCard('Saldo tersedia', money.format(s.balance), Icons.wallet)),
        Expanded(child: moneyCard('Tabungan perawatan', money.format(s.savings), Icons.savings)),
      ])),
      Card(elevation: 0, margin: const EdgeInsets.all(16), child: Padding(padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Atur penyisihan otomatis', style: TextStyle(fontWeight: FontWeight.bold)),
          Text('${s.dailyTargetPercent.toStringAsFixed(0)}% dari penghasilan selesai narik'),
          Slider(value: s.dailyTargetPercent, min: 0, max: 30, divisions: 30,
            label: '${s.dailyTargetPercent.toStringAsFixed(0)}%',
            onChanged: (v) => s.setSavingPercent(v)),
          const Text('Penyisihan otomatis dihitung saat absensi selesai disimpan.',
            style: TextStyle(fontSize: 12, color: Colors.grey)),
        ]))),
      Card(elevation: 0, margin: const EdgeInsets.symmetric(horizontal: 16), child: Padding(padding: const EdgeInsets.all(16),
        child: Column(children: [
          const Align(alignment: Alignment.centerLeft, child: Text('Catat transaksi manual',
            style: TextStyle(fontWeight: FontWeight.bold))),
          field(amount, 'Nominal (Rp)', 'Contoh: 20000', number: true),
          field(note, 'Keterangan pemasukan (opsional)', 'Contoh: bonus'),
          Wrap(spacing: 8, runSpacing: 8, children: [
            FilledButton(onPressed: saveIncome, child: const Text('Tambah pemasukan')),
            OutlinedButton(onPressed: saveMoney, child: const Text('Sisihkan ke tabungan')),
            OutlinedButton.icon(onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const QrisPage())),
              icon: const Icon(Icons.qr_code), label: const Text('QRIS')),
          ]),
        ]))),
      Padding(padding: const EdgeInsets.all(18), child: Text('Riwayat transaksi',
        style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))),
      if (s.transactions.isEmpty) const EmptyState(text: 'Belum ada transaksi.'),
      ...s.transactions.map((t) {
        final isIn = t['type'] == 'income';
        final isSaving = t['type'] == 'saving';
        return Card(elevation: 0, margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          child: ListTile(leading: CircleAvatar(child: Icon(isSaving ? Icons.savings : isIn ? Icons.add : Icons.remove)),
            title: Text(t['title']), subtitle: Text(dateFmt.format(DateTime.parse(t['date']))),
            trailing: Text('${isIn ? '+' : isSaving ? 'Tabungan ' : '-'}${money.format(t['amount'])}',
              style: TextStyle(fontWeight: FontWeight.bold, color: isIn ? Colors.green : isSaving ? Colors.blue : Colors.red))));
      }),
    ]);
  }
}

class QrisPage extends StatelessWidget {
  const QrisPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Pembayaran QRIS')),
    body: ListView(padding: const EdgeInsets.all(18), children: [
      const Text('QRIS Merchant', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Pindai QRIS berikut melalui aplikasi pembayaran yang mendukung QRIS. Pastikan nama merchant dan nominal benar sebelum membayar.'),
      const SizedBox(height: 18),
      ClipRRect(borderRadius: BorderRadius.circular(18),
        child: Image.asset('assets/images/qris_merchant.png', fit: BoxFit.contain,
          errorBuilder: (_, __, ___) => const EmptyState(text: 'Gambar QRIS belum tersedia di assets.'))),
      const SizedBox(height: 16),
      const Card(elevation: 0, child: Padding(padding: EdgeInsets.all(14), child: Text(
        'PENTING: QRIS pada versi ini ditampilkan sebagai referensi pembayaran statis. Aplikasi belum memverifikasi pembayaran secara otomatis dan tidak menambah saldo berdasarkan gambar atau bukti transfer. Untuk transaksi otomatis, hubungkan backend dengan penyedia QRIS resmi, gunakan QRIS dinamis, dan verifikasi status melalui webhook server.',
        style: TextStyle(fontSize: 13)))),
    ]),
  );
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(children: [
    pageTitle('Profil & Pengaturan', 'Pengaturan aplikasi Perawatan Motor Driver.'),
    const Card(elevation: 0, margin: EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      child: ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('Profil Driver'),
        subtitle: Text('Profil lokal perangkat — login akun belum diaktifkan.'))),
    const Card(elevation: 0, margin: EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      child: ListTile(leading: CircleAvatar(child: Icon(Icons.admin_panel_settings)), title: Text('Panel Admin'),
        subtitle: Text('Kelola katalog, harga, pengguna, dan transaksi melalui backend admin pada tahap integrasi.'))),
    const Card(elevation: 0, margin: EdgeInsets.symmetric(horizontal: 16, vertical: 5),
      child: ListTile(leading: CircleAvatar(child: Icon(Icons.cloud_done)), title: Text('Penyimpanan'),
        subtitle: Text('Versi awal menyimpan data secara lokal di perangkat menggunakan SharedPreferences.'))),
    const Padding(padding: EdgeInsets.all(18), child: Text(
      'Versi 1.0.0 • Perawatan Motor Driver\nUntuk penggunaan multi-driver, sinkronisasi cloud, login, admin online, dan pembayaran QRIS otomatis diperlukan backend produksi.',
      style: TextStyle(color: Colors.grey, fontSize: 12))),
  ]);
}

Widget field(TextEditingController c, String label, String hint, {bool number = false}) =>
  Padding(padding: const EdgeInsets.only(bottom: 10), child: TextField(
    controller: c,
    keyboardType: number ? const TextInputType.numberWithOptions(decimal: true) : TextInputType.text,
    decoration: InputDecoration(labelText: label, hintText: hint, border: const OutlineInputBorder()),
  ));

class EmptyState extends StatelessWidget {
  final String text;
  const EmptyState({super.key, required this.text});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.all(24),
    child: Center(child: Column(children: [
      Icon(Icons.inbox_outlined, size: 38, color: Colors.grey.shade400),
      const SizedBox(height: 8),
      Text(text, textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade600)),
    ])),
  );
}
