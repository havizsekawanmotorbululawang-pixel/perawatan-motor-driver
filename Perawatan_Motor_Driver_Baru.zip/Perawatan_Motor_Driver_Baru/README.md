# Perawatan Motor Driver — proyek baru

## Desain
Tema modern navy, biru, dan kuning; logo PMD; navigasi bawah; kartu dashboard.

## Fitur prototipe
- Beranda dan navigasi enam menu.
- Profil driver/kendaraan disimpan lokal dengan SharedPreferences.
- Absensi foto menggunakan kamera.
- Kilometer dan perhitungan perkiraan jadwal oli.
- Katalog contoh produk dan harga.
- Halaman keuangan (belum ada penyimpanan transaksi).
- Halaman QRIS sebagai placeholder.

## Penting sebelum dipakai sungguhan
1. Tambahkan gambar QRIS merchant yang benar ke `assets/images/qris_merchant.png` dan daftarkan di pubspec.
2. Harga katalog adalah data contoh; verifikasi dan sesuaikan dengan produk/toko.
3. Absensi saat ini hanya konfirmasi sesi aplikasi; belum ada backend, akun, sinkronisasi, atau laporan admin.
4. Riwayat transaksi dan penyimpanan foto absensi permanen perlu implementasi lanjutan.
5. Jangan menganggap QRIS sudah memproses atau memverifikasi pembayaran otomatis.
6. Tidak ada AdMob/iklan.

## Menjalankan
- Instal Flutter SDK.
- Jalankan `flutter create .` dari folder proyek untuk menghasilkan folder platform Android/iOS dan wrapper sesuai versi Flutter lokal.
- Jalankan `flutter pub get`.
- Jalankan `flutter run`.

Proyek ini adalah source awal Flutter. Build APK belum dijalankan/diuji dalam lingkungan pembuatan ZIP ini.
