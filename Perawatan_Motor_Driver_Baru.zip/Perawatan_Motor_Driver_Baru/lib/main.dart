import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

void main() => runApp(const PMDApp());

const navy = Color(0xFF0B1730);
const blue = Color(0xFF1769D2);
const yellow = Color(0xFFFFC928);
const bg = Color(0xFFF3F6FB);

class PMDApp extends StatelessWidget {
  const PMDApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Perawatan Motor Driver',
    theme: ThemeData(
      useMaterial3: true, scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: blue),
      fontFamily: 'Roboto',
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: navy, elevation: 0),
    ),
    home: const HomeShell(),
  );
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  String driver = 'Nama Driver';
  String vehicle = 'Honda Beat';
  String plate = '-';
  int odo = 12500;
  int lastOil = 10000;
  int interval = 2000;
  final picker = ImagePicker();
  File? attendancePhoto;
  final money = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      driver = p.getString('driver') ?? driver;
      vehicle = p.getString('vehicle') ?? vehicle;
      plate = p.getString('plate') ?? plate;
      odo = p.getInt('odo') ?? odo;
      lastOil = p.getInt('lastOil') ?? lastOil;
      interval = p.getInt('interval') ?? interval;
    });
  }
  @override void initState() { super.initState(); load(); }

  Future<void> saveInt(String key, int value) async {
    final p = await SharedPreferences.getInstance(); await p.setInt(key, value);
  }
  Future<void> takePhoto() async {
    final x = await picker.pickImage(source: ImageSource.camera, imageQuality: 75);
    if (x != null && mounted) setState(() => attendancePhoto = File(x.path));
  }
  void go(int i) => setState(() => tab = i);

  @override Widget build(BuildContext context) {
    final pages = [
      dashboard(), attendance(), maintenance(), catalog(), finance(), profile()
    ];
    return Scaffold(
      body: SafeArea(child: IndexedStack(index: tab, children: pages)),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab, onDestinationSelected: go,
        backgroundColor: Colors.white, indicatorColor: blue.withOpacity(.12),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Beranda'),
          NavigationDestination(icon: Icon(Icons.fact_check_rounded), label: 'Absensi'),
          NavigationDestination(icon: Icon(Icons.build_circle_rounded), label: 'Servis'),
          NavigationDestination(icon: Icon(Icons.storefront_rounded), label: 'Katalog'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_rounded), label: 'Keuangan'),
          NavigationDestination(icon: Icon(Icons.person_rounded), label: 'Profil'),
        ],
      ),
    );
  }

  Widget header(String title, String sub, {Widget? trailing}) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 14, 20, 12),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: navy)),
        const SizedBox(height: 3), Text(sub, style: TextStyle(color: Colors.blueGrey.shade600, fontSize: 12)),
      ])),
      if (trailing != null) trailing!,
    ]),
  );
  Widget card(Widget child, {EdgeInsets padding = const EdgeInsets.all(16)}) =>
    Container(width: double.infinity, padding: padding, decoration: BoxDecoration(
      color: Colors.white, borderRadius: BorderRadius.circular(20),
      boxShadow: [BoxShadow(color: navy.withOpacity(.045), blurRadius: 18, offset: const Offset(0,6))],
    ), child: child);
  Widget dashboard() => ListView(padding: EdgeInsets.zero, children: [
    Container(
      margin: const EdgeInsets.fromLTRB(16, 10, 16, 18), padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(gradient: const LinearGradient(colors: [navy, Color(0xFF174F9C)]),
        borderRadius: BorderRadius.circular(26)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          ClipRRect(borderRadius: BorderRadius.circular(13), child: Image.asset('assets/images/pmd_logo.png', width: 54, height: 54, fit: BoxFit.cover,
            errorBuilder: (_,__,___) => const Icon(Icons.two_wheeler, color: yellow, size: 42))),
          const SizedBox(width: 12),
          const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('PERAWATAN MOTOR', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: 1)),
            Text('DRIVER', style: TextStyle(color: yellow, fontWeight: FontWeight.w900, fontSize: 12)),
          ])),
          const Icon(Icons.notifications_active_outlined, color: Colors.white),
        ]),
        const SizedBox(height: 25),
        Text('Halo, $driver 👋', style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        const Text('Kendaraan sehat, perjalanan lancar.', style: TextStyle(color: Colors.white70)),
        const SizedBox(height: 20),
        Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: Colors.white.withOpacity(.10), borderRadius: BorderRadius.circular(17)),
          child: Row(children: [
            const Icon(Icons.two_wheeler, color: yellow, size: 34), const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(vehicle, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
              Text('No. Polisi: $plate', style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              const Text('ODOMETER', style: TextStyle(color: Colors.white60, fontSize: 9)),
              Text('$odo KM', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 18)),
            ]),
          ])),
      ]),
    ),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 20), child: Row(children: [
      const Expanded(child: Text('Menu Utama', style: TextStyle(color: navy, fontWeight: FontWeight.w900, fontSize: 18))),
      TextButton(onPressed: () => go(5), child: const Text('Edit profil')),
    ])),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: GridView.count(
      crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.55,
      children: [
        menuTile(Icons.camera_alt_rounded, 'Absensi Foto', 'Catat aktivitas', 1, const Color(0xFFE8F1FF)),
        menuTile(Icons.oil_barrel_rounded, 'Perawatan Oli', 'Jadwal penggantian', 2, const Color(0xFFFFF5D9)),
        menuTile(Icons.shopping_bag_rounded, 'Katalog Produk', 'Produk & harga', 3, const Color(0xFFE6F8F2)),
        menuTile(Icons.wallet_rounded, 'Keuangan', 'Catatan biaya', 4, const Color(0xFFF1EBFF)),
      ],
    )),
    Padding(padding: const EdgeInsets.fromLTRB(16,18,16,25), child: card(Row(children: [
      const Icon(Icons.qr_code_2_rounded, color: blue, size: 36), const SizedBox(width: 12),
      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Pembayaran QRIS', style: TextStyle(fontWeight: FontWeight.bold, color: navy)),
        Text('Lihat kode pembayaran', style: TextStyle(color: Colors.blueGrey, fontSize: 12)),
      ])),
      FilledButton(onPressed: showQris, child: const Text('Buka')),
    ]))),
  ]);
  Widget menuTile(IconData icon, String title, String sub, int index, Color tint) => InkWell(
    borderRadius: BorderRadius.circular(20), onTap: () => go(index),
    child: card(Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
      Container(padding: const EdgeInsets.all(9), decoration: BoxDecoration(color: tint, borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: navy)),
      const SizedBox(height: 9), Text(title, style: const TextStyle(color: navy, fontWeight: FontWeight.bold)),
      Text(sub, style: const TextStyle(color: Colors.blueGrey, fontSize: 11)),
    ]), padding: const EdgeInsets.all(13)),
  );

  Widget attendance() => ListView(children: [
    header('Absensi Driver', 'Dokumentasikan aktivitas dan kilometer'),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Foto bukti absensi', style: TextStyle(fontWeight: FontWeight.bold, color: navy)),
      const SizedBox(height: 12),
      if (attendancePhoto != null) ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.file(attendancePhoto!, height: 190, width: double.infinity, fit: BoxFit.cover))
      else Container(height: 150, width: double.infinity, decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14)),
        child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(Icons.add_a_photo_outlined, size: 42, color: blue), SizedBox(height: 8), Text('Ambil foto saat mulai / selesai')])),
      const SizedBox(height: 12), SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: takePhoto, icon: const Icon(Icons.camera_alt), label: const Text('Ambil Foto Kamera'))),
      const SizedBox(height: 18), const Text('Kilometer saat ini', style: TextStyle(fontWeight: FontWeight.bold)),
      TextFormField(initialValue: '$odo', keyboardType: TextInputType.number, decoration: const InputDecoration(suffixText: 'KM', border: OutlineInputBorder()),
        onChanged: (v) { final n=int.tryParse(v); if(n!=null){odo=n; saveInt('odo',n);} }),
      const SizedBox(height: 12), SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () {
        if(attendancePhoto==null){ ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ambil foto absensi terlebih dahulu'))); return; }
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Absensi tersimpan di sesi aplikasi ini')));
      }, icon: const Icon(Icons.check_circle), label: const Text('Simpan Absensi'))),
    ]))),
  ]);
  Widget maintenance() {
    final due = lastOil + interval;
    final remaining = due - odo;
    final ok = remaining > 0;
    return ListView(children: [
      header('Perawatan Motor', 'Pantau jadwal servis kendaraan'),
      Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [const Icon(Icons.oil_barrel, color: blue, size: 30), const SizedBox(width: 10), const Expanded(child: Text('Penggantian Oli Mesin', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17, color: navy))), Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7), decoration: BoxDecoration(color: ok? const Color(0xFFE3F8EC):const Color(0xFFFFE8E8), borderRadius: BorderRadius.circular(20)), child: Text(ok?'MASIH BAGUS':'SEGERA GANTI', style: TextStyle(color: ok?Colors.green.shade800:Colors.red.shade800, fontWeight: FontWeight.bold, fontSize: 10)))]),
        const SizedBox(height: 18), Text(ok?'Sisa $remaining KM':'Terlambat ${remaining.abs()} KM', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: ok?Colors.green:Colors.red)),
        const Text('Perkiraan berdasarkan kilometer kendaraan', style: TextStyle(color: Colors.blueGrey, fontSize: 12)),
        const Divider(height: 28),
        TextFormField(initialValue: '$lastOil', keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'KM terakhir ganti oli', suffixText: 'KM', border: OutlineInputBorder()),
          onChanged: (v){final n=int.tryParse(v);if(n!=null){lastOil=n;saveInt('lastOil',n);setState((){});}}),
        const SizedBox(height: 10),
        TextFormField(initialValue: '$interval', keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Interval penggantian', suffixText: 'KM', border: OutlineInputBorder()),
          onChanged: (v){final n=int.tryParse(v);if(n!=null){interval=n;saveInt('interval',n);setState((){});}}),
        const SizedBox(height: 12), SizedBox(width: double.infinity, child: FilledButton(onPressed: (){setState(()=>lastOil=odo);saveInt('lastOil',odo);}, child: const Text('Tandai Sudah Ganti Oli'))),
      ]))),
      Padding(padding: const EdgeInsets.all(16), child: card(const Text('Tips: periksa kondisi oli secara berkala. Interval dapat berbeda sesuai rekomendasi pabrikan dan kondisi penggunaan.', style: TextStyle(color: Colors.blueGrey)))),
    ]);
  }
  Widget catalog() => ListView(children: [
    header('Katalog Produk', 'Contoh daftar produk dan estimasi harga'),
    product('Oli Mesin Matic 0.8L', 'Oli mesin untuk motor matic', 'Rp 55.000', Icons.oil_barrel),
    product('Oli Mesin Bebek 0.8L', 'Oli mesin motor bebek', 'Rp 52.000', Icons.oil_barrel),
    product('Kampas Rem Depan', 'Suku cadang pengereman', 'Rp 35.000', Icons.settings),
    product('Busi Standar', 'Busi pengapian motor', 'Rp 18.000', Icons.electric_bolt),
    product('Ban Tubeless', 'Pilihan ukuran sesuai kendaraan', 'Mulai Rp 180.000', Icons.tire_repair),
  ]);
  Widget product(String name,String desc,String price,IconData icon)=>Padding(padding: const EdgeInsets.fromLTRB(16,0,16,12), child: card(Row(children: [
    Container(width:65,height:65,decoration:BoxDecoration(color:bg,borderRadius:BorderRadius.circular(14)),child:Icon(icon,color:blue,size:32)),
    const SizedBox(width:12), Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(name,style:const TextStyle(fontWeight:FontWeight.bold,color:navy)),Text(desc,style:const TextStyle(fontSize:11,color:Colors.blueGrey)),const SizedBox(height:5),Text(price,style:const TextStyle(fontWeight:FontWeight.w900,color:blue))])),
    IconButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$name dipilih'))),icon:const Icon(Icons.add_shopping_cart,color:blue)),
  ])));
  Widget finance() => ListView(children: [
    header('Keuangan', 'Ringkasan pengeluaran perawatan'),
    Padding(padding: const EdgeInsets.symmetric(horizontal:16), child: card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Catatan Pengeluaran',style:TextStyle(fontWeight:FontWeight.bold,color:navy)),
      const SizedBox(height:8), const Text('Catat biaya servis, oli, dan suku cadang kendaraan.',style:TextStyle(color:Colors.blueGrey,fontSize:12)),
      const SizedBox(height:14), FilledButton.icon(onPressed:()=>showDialog(context:context,builder:(c)=>AlertDialog(title:const Text('Tambah pengeluaran'),content:const Text('Fitur pencatatan transaksi akan disimpan pada pengembangan berikutnya.'),actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Tutup'))])),icon:const Icon(Icons.add),label:const Text('Tambah Catatan')),
    ]))),
    Padding(padding: const EdgeInsets.all(16), child: card(Row(children:[const Icon(Icons.info_outline,color:blue),const SizedBox(width:10),const Expanded(child:Text('Belum ada transaksi yang dicatat.',style:TextStyle(color:Colors.blueGrey)))]))),
  ]);
  Widget profile() => ListView(children: [
    header('Profil Driver', 'Data pengemudi dan kendaraan'),
    Padding(padding: const EdgeInsets.symmetric(horizontal:16), child: card(Column(children:[
      const CircleAvatar(radius:36,backgroundColor:bg,child:Icon(Icons.person,color:blue,size:38)),
      const SizedBox(height:16),
      TextFormField(initialValue:driver,decoration:const InputDecoration(labelText:'Nama driver',border:OutlineInputBorder()),onChanged:(v)async{driver=v;final p=await SharedPreferences.getInstance();await p.setString('driver',v);}),
      const SizedBox(height:12),
      TextFormField(initialValue:vehicle,decoration:const InputDecoration(labelText:'Jenis / model motor',border:OutlineInputBorder()),onChanged:(v)async{vehicle=v;final p=await SharedPreferences.getInstance();await p.setString('vehicle',v);}),
      const SizedBox(height:12),
      TextFormField(initialValue:plate,decoration:const InputDecoration(labelText:'Nomor polisi',border:OutlineInputBorder()),onChanged:(v)async{plate=v;final p=await SharedPreferences.getInstance();await p.setString('plate',v);}),
      const SizedBox(height:14),SizedBox(width:double.infinity,child:FilledButton(onPressed:()=>ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Profil tersimpan di perangkat'))),child:const Text('Simpan Profil'))),
    ]))),
    Padding(padding:const EdgeInsets.all(16),child:card(const Row(children:[Icon(Icons.verified_user,color:blue),SizedBox(width:10),Expanded(child:Text('Data contoh disimpan secara lokal di perangkat. Tidak memerlukan akun.',style:TextStyle(color:Colors.blueGrey,fontSize:12)))]))),
  ]);
  void showQris() => showDialog(context:context,builder:(c)=>AlertDialog(
    title:const Text('Pembayaran QRIS'),
    content:Column(mainAxisSize:MainAxisSize.min,children:[
      const Icon(Icons.qr_code_2,size:110,color:navy),
      const Text('Tempatkan gambar QRIS merchant asli pada assets/images/qris_merchant.png dan tambahkan ke pubspec.yaml untuk menampilkannya di sini.',textAlign:TextAlign.center,style:TextStyle(fontSize:12)),
      const SizedBox(height:8),const Text('Pembayaran belum diverifikasi otomatis.',style:TextStyle(color:Colors.red,fontSize:11)),
    ]),
    actions:[TextButton(onPressed:()=>Navigator.pop(c),child:const Text('Tutup'))],
  ));
}
