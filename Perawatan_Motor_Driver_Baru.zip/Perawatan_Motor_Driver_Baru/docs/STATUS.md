Source awal dibuat ulang. Tidak ada AdMob. Lihat README untuk batasan prototipe dan langkah berikutnya.
