# Perawatan Motor Driver — Flutter

Proyek Flutter Android berbahasa Indonesia untuk pencatatan aktivitas driver dan perawatan motor.

## Fitur yang sudah ada pada source versi awal
- Dashboard ringkasan saldo, tabungan, pemasukan dan pengeluaran.
- Absensi mulai/selesai narik dengan kilometer awal/akhir.
- Perhitungan jarak tempuh.
- Penyisihan otomatis berdasarkan persentase penghasilan saat selesai narik.
- Penyisihan manual ke tabungan.
- Katalog contoh sparepart dan ongkos jasa.
- Catatan riwayat perawatan.
- Riwayat transaksi.
- Halaman QRIS yang menampilkan gambar merchant yang disediakan.
- Penyimpanan lokal di perangkat menggunakan SharedPreferences.

## Batasan penting versi 1.0.0
Ini adalah fondasi aplikasi yang bisa dijalankan dan dikembangkan, belum merupakan layanan multi-pengguna produksi. Login/registrasi, panel admin online, sinkronisasi cloud, manajemen stok, notifikasi terjadwal, pemesanan bengkel, dan pembayaran QRIS otomatis membutuhkan backend serta konfigurasi layanan yang sah.

QRIS yang disertakan adalah gambar statis merchant. Aplikasi tidak memverifikasi pembayaran dan tidak boleh menambah saldo otomatis dari screenshot/bukti transfer. Untuk pembayaran otomatis, integrasikan penyedia QRIS resmi (QRIS dinamis), backend aman, dan verifikasi webhook.

Harga katalog merupakan data contoh dan perlu dikonfirmasi/diperbarui oleh pengelola.

## Menjalankan di komputer
Persyaratan: Flutter SDK stabil, Android SDK, Android Studio atau command-line tools, dan Java sesuai versi Flutter.

```bash
flutter doctor
flutter create --platforms=android --org id.drivercare .
flutter pub get
flutter run
```

## Build APK release
```bash
flutter build apk --release
```
APK akan dibuat di:
`build/app/outputs/flutter-apk/app-release.apk`

## Build APK melalui GitHub Actions
1. Buat repository GitHub baru.
2. Upload seluruh isi ZIP ini ke repository.
3. Buka tab Actions.
4. Jalankan workflow `Build Android APK`.
5. Setelah selesai, unduh artifact `perawatan-motor-driver-apk`.

Workflow akan membuat folder platform Android menggunakan Flutter CLI, mengambil dependency, lalu membangun APK release.

## QRIS
File QRIS ada di `assets/images/qris_merchant.png`. Ganti file tersebut hanya dengan QRIS merchant yang benar-benar dimiliki/diizinkan untuk digunakan.
